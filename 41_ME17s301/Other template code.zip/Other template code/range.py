import numpy as np 
sigma = list(np.linspace(-10e10, 10e9, 100))
print('sigma: ', sigma)
