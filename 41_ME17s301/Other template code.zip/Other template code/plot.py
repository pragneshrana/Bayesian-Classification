
std_devi = []
mean_data = [] 
import pandas as pd 
import numpy as np
import matplotlib.pyplot as plt
number =[5,10]

import os
os.chdir(os.path.dirname(__file__))
path  = os.getcwd()

for j in range(len(number)):
    Accuracy_data = pd.read_csv('Accuracy_result_'+str(number[j])+'.csv')
    std_devi.append(Accuracy_data.stack().std() )
    mean_data.append(Accuracy_data.stack().mean() )

x_pos = np.arange(len(number))
print('x_pos: ', x_pos)
CTEs = mean_data
print('CTEs: ', CTEs)
error = std_devi
print('error: ', error)

# Build the plot
fig, ax = plt.subplots()
ax.bar(x_pos, CTEs, yerr=error, align='center', alpha=0.5, ecolor='black', capsize=10)
ax.set_ylabel('Accuracy ')
ax.set_xticks(x_pos)
ax.set_title('Dataset Size')
ax.yaxis.grid(True)

# Save the figure and show
plt.tight_layout()
plt.savefig('error_bars.png')
plt.show()

