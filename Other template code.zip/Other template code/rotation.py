import numpy as np
cov_mat = np.matrix([[1,2,3],
                      [4,5,6],
                      [7,8,9]])

W,V = np.linalg.eig(cov_mat)
print('V: ', V)
V[:,0], V[:,1]
print('V[:,0], V[:,1]: ', V[:,0], V[:,1])